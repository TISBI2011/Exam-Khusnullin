﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Exam_Khusnullin.Models;

namespace Exam_Khusnullin.Pages
{
    /// <summary>
    /// Логика взаимодействия для MenedjerPage.xaml
    /// </summary>
    public partial class MenedjerPage : Page
    {
        public MenedjerPage()
        {
            InitializeComponent();
            DGSotrudnik.ItemsSource = App.DB.Sotrudnik.ToList();
            CBDoljnost.ItemsSource = App.DB.Doljnost.ToList();
            Refresh();
        }

        private void TBPoisk_TextChanged(object sender, TextChangedEventArgs e)
        {
            var filtred = App.DB.Sotrudnik.ToList();
            var searchText = TBPoisk.Text.ToLower();

            if (!string.IsNullOrWhiteSpace(searchText))
                filtred = filtred.Where(x => x.FIO.ToLower().Contains(searchText)).ToList();
            DGSotrudnik.ItemsSource = filtred.ToList();
        }

        private void CBDoljnost_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Refresh();
        }
        private void Refresh()
        {
            var filtred = App.DB.Sotrudnik.ToList();
            var selectedSotrudnik = CBDoljnost.SelectedItem as Doljnost;
            if (selectedSotrudnik != null)
                filtred = filtred.Where(x => x.IDDoljnost == selectedSotrudnik.IDDoljnost).ToList();
        }

        private void BAddSotrudnik_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BRedSotrudnik_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BDeleteSotridnik_Click(object sender, RoutedEventArgs e)
        {
            var deleteuser = DGSotrudnik.SelectedItem as Sotrudnik;
            if (deleteuser == null)
            {
                MessageBox.Show("Выберите пользователя");
                return;
            }
            App.DB.Sotrudnik.Remove(deleteuser);
            App.DB.SaveChanges();
            DGSotrudnik.ItemsSource = App.DB.Sotrudnik.ToList();
        }
    }
}
