﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Exam_Khusnullin.Models;

namespace Exam_Khusnullin.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void BAutorez_Click(object sender, RoutedEventArgs e)
        {
            string login = TBLogin.Text;
            string password = TBPassword.Text;
            string secret = TBSecret.Text;
            var loggerUser = App.DB.Sotrudnik.FirstOrDefault(x => x.Login == login && x.Password == password && x.Secret == secret);

            if (loggerUser == null)
            {
                MessageBox.Show("Не верный логин или пароль ИЛИ СЕКРКТНОЕ СЛОВО");
                return;
            }
            
            if (loggerUser.IDDoljnost == 1)
            {
                NavigationService.Navigate(new MenedjerPage());
                MessageBox.Show("Добро пожаловать ");
            }
            if (loggerUser.IDDoljnost == 2)
            {
                NavigationService.Navigate(new KolCentrPage());
                MessageBox.Show("Добро пожаловать ");
            }
            if (loggerUser.IDDoljnost == 3)
            {
                NavigationService.Navigate(new KliningPage());
                MessageBox.Show("Добро пожаловать ");
            }
        }
    }
}
